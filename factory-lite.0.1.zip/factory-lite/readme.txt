=== Factory Lite ===
Contributors: VWThemes
Tags: left-sidebar, right-sidebar, one-column, two-columns, grid-layout, wide-blocks, block-styles, block-patterns, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, flexible-header, sticky-post, full-width-template, theme-options, translation-ready, rtl-language-support, threaded-comments, blog, portfolio, e-commerce
Requires at least: 5.0
Tested up to: 5.7
Requires PHP: 7.2
Stable tag: 0.1
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Factory Lite is a sophisticated theme that serves industries, factories, construction businesses, mining, petroleum and crude oil industry, heavy engineering, and power sector. Designed to cater to the needs of niche businesses related to factories and industries, Factory Lite can be used as a multipurpose theme for several business endeavors. Its super elegant layout is crafted by experts making all the content look very clean and properly placed. 

== Description ==

Factory Lite is a sophisticated theme that serves industries, factories, construction businesses, mining, petroleum and crude oil industry, heavy engineering, and power sector. Designed to cater to the needs of niche businesses related to factories and industries, Factory Lite can be used as a multipurpose theme for several business endeavors. Its super elegant layout is crafted by experts making all the content look very clean and properly placed. The main focus was on bringing a user-friendly design that can be used by anyone with or without coding skills. Though it is a free theme, it will still make your website look no less than crafted by a skilled professional as it has a stunning layout backed by secure and clean codes improving the working of your site. It makes your website fully accessible through mobile phones and other devices as it possesses a mobile-friendly design. Enough customization options are made available for you to make a few tweaks without much effort. To make it more interactive and engaging, there are a lot of Call To Action Buttons (CTA) and along with this, the design is made translation ready to support multiple local and global languages. Its Bootstrap-based design is capable of delivering a modern website.

== Changelog ==

= 0.1 =
* Initial version released.

== Resources ==

Factory Lite WordPress Theme, Copyright 2021 VWThemes
Factory Lite is distributed under the terms of the GNU GPL.

Theme is Built using the following resource bundles.

= Bootstrap =
* Mark Otto
* copyright 2011-2020, Mark Otto
* https://github.com/twbs/bootstrap/releases/download/v4.0.0/bootstrap-4.0.0-dist.zip
* License: Code released under the MIT License. v4.4.1
* https://github.com/twbs/bootstrap/blob/master/LICENSE

= Font-Awesome =
* Davegandy
* copyright July 12, 2018, Davegandy
* https://github.com/FortAwesome/Font-Awesome.git
* License: Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License
* https://github.com/FortAwesome/Font-Awesome/blob/master/LICENSE.txt

= Customizer Pro =
* Justin Tadlock
* Copyright 2016, Justin Tadlock
* https://github.com/justintadlock/trt-customizer-pro.git
* License: GNU General Public License v2.0
* http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

= Superfish =
* Joeldbirch
* Copyright 2013, Justin Tadlock
* https://github.com/joeldbirch/superfish.git
* License: Free to use and abuse under the MIT license. v1.7.9
* https://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

= Typography =
* Justin Tadlock
* Copyright 2015, Justin Tadlock
* https://github.com/justintadlock/customizer-typography.git
* License: GNU General Public License v2.0
* https://github.com/justintadlock/customizer-typography/blob/master/license.md

* Pxhere Images,
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/license

Slider Image, Copyright 
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/653857

Services Image, Copyright
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1218559

* All the icons taken from genericons licensed under GPL License.
http://genericons.com/

== Theme Documentation ==
Documentation : https://www.vwthemesdemo.com/docs/free-factory-lite/